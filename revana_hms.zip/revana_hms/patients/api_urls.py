from patients.views import PatientViewSet

router.register(r'patients', PatientViewSet)
